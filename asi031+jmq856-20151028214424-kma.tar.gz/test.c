
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <stdio.h>

#define MIN_BUFFER_SIZE 32
			// index 	0  | 1  |  2  |  3  |  4  |  5   |  6   |   7
#define BUFFER_NUM 9 // 32 | 64 | 128 | 256 | 512 | 1024 | 2048 | 4096
#define BITMAP_NUM 8192 / MIN_BUFFER_SIZE / sizeof(int) / 8


typedef struct page_node{
	//block_node_t* first_free_block;
	void* ptr_back;
	struct page_node* next_page;
	//bool of;
	int bitmap[BITMAP_NUM];
}page_node_t;

int find_block_index(int size) {
	int index = 0;
	while(size != 0){
		index++;
		size = size >> 1;
	}
	return index - 6;
}

int find_round_size(int size) {
	if(size == 0) return 0;
	int round_size = 1;
	while(round_size < size){
		round_size <<= 1;
	}
	return round_size < MIN_BUFFER_SIZE ? MIN_BUFFER_SIZE : round_size;
}


main(int argc, char* argv[])
{
	int bitmap[BITMAP_NUM];
	printf("here: %d, %d, %d\n", (int)sizeof(page_node_t), 
								(int)sizeof(page_node_t*), 
								(int)sizeof(bitmap));
	//printf("here: %d\n", find_block_index(128));
	//printf("here: %d\n", find_round_size(0));


	return 0;
}